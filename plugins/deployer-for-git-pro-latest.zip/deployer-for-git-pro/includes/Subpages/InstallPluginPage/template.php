<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<?php if ( isset( $install_result ) ) : ?>
	<?php if ( ! is_wp_error( $install_result ) ) : ?>
		<div class="updated">
			<p>
				<?php echo esc_attr__( 'Plugin was successfully installed', 'deployer-for-git' ); ?>
			</p>
		</div>
	<?php else : ?>
		<div class="error">
			<p>
				<!-- <strong><?php echo esc_attr( $install_result->get_error_code() ); ?></strong> -->
				<?php echo esc_attr( $install_result->get_error_message() ); ?>
			</p>
		</div>
	<?php endif; ?>
<?php endif; ?>

<div class="wrap">
	<h1><?php echo esc_attr__( 'Install Plugin', 'deployer-for-git' ); ?></h1>
	<form class="dfg_install_package_form" method="post" action="">
		<input type="hidden" name="<?php echo esc_attr( DFG_SLUG . '_install_package_submitted' ); ?>" value="1">
		<input type="hidden" name="package_type" value="plugin">

		<?php wp_nonce_field( DFG_SLUG . '_install_package_form', DFG_SLUG . '_nonce' ); ?>
		<table class="form-table">
			<tr valign="top">
				<th scope="row">
					<?php echo esc_attr__( 'Provider Type', 'deployer-for-git' ); ?>
				</th>
				<td>
					<select name='provider_type'>
						<option value="" selected disabled><?php echo esc_attr__( 'Choose a provider', 'deployer-for-git' ); ?></option>
						<?php foreach ( \DeployerForGit\Helper::available_providers() as $provider_id => $name ) : ?>
							<option value="<?php echo esc_attr( $provider_id ); ?>"><?php echo esc_attr( $name ); ?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><?php echo esc_attr__( 'Repository URL', 'deployer-for-git' ); ?></th>
				<td>
					<input type="url" class="regular-text code" name="repository_url" value="" />
					<p class="description dfg_repo_url_description dfg_hidden" id="bitbucket-repo-url-description"><?php echo esc_attr__( 'Example: https://bitbucket.org/owner/wordpress-plugin-name', 'deployer-for-git' ); ?></p>
					<p class="description dfg_repo_url_description dfg_hidden" id="github-repo-url-description"><?php echo esc_attr__( 'Example: https://github.com/owner/wordpress-plugin-name', 'deployer-for-git' ); ?></p>
					<p class="description dfg_repo_url_description dfg_hidden" id="gitea-repo-url-description"><?php echo esc_attr__( 'Example: https://gitea.com/owner/wordpress-plugin-name', 'deployer-for-git' ); ?></p>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row"><?php echo esc_attr__( 'Branch', 'deployer-for-git' ); ?> <span class="dashicons dashicons-randomize"></span></th>
				<td>
					<input type="text" class="" placeholder="master" name="repository_branch" value="" />
					<p class="description"><?php echo esc_attr__( 'default is "master"', 'deployer-for-git' ); ?></p>
				</td>
			</tr>

			<?php
			if ( dfg_fs()->is__premium_only() ) {

				if ( dfg_fs()->can_use_premium_code() ) {
					$private_repository_row_class = 'pro';
				} else {
					$private_repository_row_class = 'no_license';
				}
			} else {
				$private_repository_row_class = 'free';
			}
			?>

			<tr valign="top" class="dfg_hidden dfg_is_private_repository_row <?php echo esc_attr( $private_repository_row_class ); ?>">
				<th scope="row">
					<?php echo esc_attr__( 'Is Private Repository', 'deployer-for-git' ); ?>

					<?php if ( dfg_fs()->is__premium_only() ) : ?>
						<?php if ( dfg_fs()->can_use_premium_code() ) : ?>
						<?php else : ?>
							<br>
							<small><?php echo esc_attr__( '[Active license required]', 'deployer-for-git' ); ?></small>
						<?php endif; ?>
					<?php else : ?>
						<br>
						<small><?php echo esc_attr__( '[Available in PRO version]', 'deployer-for-git' ); ?></small>
					<?php endif; ?>

					<span class="dashicons dashicons-lock"></span>
				</th>
				<td><input type="checkbox" name="is_private_repository" value="1"></td>
			</tr>

			<?php
			if ( dfg_fs()->is__premium_only() ) :

				if ( dfg_fs()->can_use_premium_code() ) :
					?>
					<tr valign="top" class="dfg_hidden dfg_username_row">
						<th scope="row"><?php echo esc_attr__( 'Username', 'deployer-for-git' ); ?></th>
						<td><input type="text" name="username" value=""></td>
					</tr>
					<tr valign="top" class="dfg_hidden dfg_password_row">
						<th scope="row"><?php echo esc_attr__( 'Password', 'deployer-for-git' ); ?></th>
						<td><input type="text" name="password" value=""></td>
					</tr>
					<tr valign="top" class="dfg_hidden dfg_access_token_row">
						<th scope="row"><?php echo esc_attr__( 'Access Token', 'deployer-for-git' ); ?></th>
						<td>
							<input class="regular-text code" type="text" name="access_token" value="">
							<p id="gitea-access-token-description" class="description dfg_access_token_description dfg_hidden">
							<?php echo esc_attr__( 'You can generate Gitea access token here:', 'deployer-for-git' ); ?>
								<a href="https://gitea.com/user/settings/applications" target="_blank" rel="nofollow"><?php echo esc_attr__( 'Link', 'deployer-for-git' ); ?></a>
							</p>
							<p id="github-access-token-description" class="description dfg_access_token_description dfg_hidden">
							<?php echo esc_attr__( 'You can generate Github access token here:', 'deployer-for-git' ); ?>
								<a href="https://github.com/settings/tokens" target="_blank" rel="nofollow"><?php echo esc_attr__( 'Link', 'deployer-for-git' ); ?></a>
							</p>
							<p id="gitlab-access-token-description" class="description dfg_access_token_description dfg_hidden">
							<?php echo esc_attr__( 'You can generate GitLab access token here ("api" scope required):', 'deployer-for-git' ); ?>
								<a href="https://gitlab.com/-/profile/personal_access_tokens" target="_blank" rel="nofollow"><?php echo esc_attr__( 'Link', 'deployer-for-git' ); ?></a>
							</p>
						</td>
					</tr>
						<?php
					endif;
				endif;
			?>
		</table>
		<div class="submit">
			<input type="submit" class="button-primary" value="<?php echo esc_attr__( 'Install Plugin', 'deployer-for-git' ); ?>" /><br><br>
			<p class="description"><i><?php echo esc_attr__( 'Note that if a plugin with specified slug is already installed, this action will overwrite the already existing plugin.', 'deployer-for-git' ); ?><i></p>
		</div>
	</form>
</div>
